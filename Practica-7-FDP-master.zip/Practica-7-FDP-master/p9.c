#include <stdio.h>
#include <stdlib.h>
int main(){
	short v1;//Valor tipo short.
	unsigned short v2;//Valor tipo short sin signo
	signed short v3;//Valor tipo short con signo
	int v4;// valor tipo entero
	signed int v5;//valor tipo entero con signo
	unsigned int v6; //Valor tipo entero con signo
	long v7; // valor tipo long
	signed long v8; // Valor tipo long con signo
	unsigned long v9; // Valor tipo long sin signo
	printf("Ingresa valor tipo short\n");
	scanf("%hd" , &v1);
	printf("Ingresa valor tipo short sin signo\n");
        scanf("%hd" , &v2);
	printf("Ingresa valor tipo short con signo\n");
        scanf("%hd" , &v3);
	printf("Ingresa valor tipo entero\n");
        scanf("%d" , &v4);
	printf("Ingresa valor tipo entero con signo\n");
        scanf("%d" , &v5);
	printf("Ingresa valor tipo entero sin signo\n");
        scanf("%d" , &v6);
	printf("Ingresa valor tipo long\n");
        scanf("%ld" , &v7);
	printf("Ingresa valor tipo long con signo\n");
        scanf("%ld" , &v8);
	printf("Ingresa valor tipo long sin signo\n");
        scanf("%ld" , &v9);
	printf("%hd\n", v1);
	printf("%hd\n", v2);
	printf("%hd\n", v3);
	printf("%d\n", v4);
        printf("%d\n", v5);
        printf("%d\n", v6);
	printf("%ld\n", v7);
        printf("%ld\n", v8);
        printf("%ld\n", v9);
	return 0;
}
