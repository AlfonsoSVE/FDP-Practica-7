#include<stdio.h>
#include<stdlib.h>
int main(){
	float v1; //Valor tipo float
	double v2; //valor tipo double
	long double v3; // Valor tipo long double

	printf("Ingrese valor tipo float\n");
	scanf("%f",&v1);
	printf("Ingrese valor tipo double\n");
	scanf("%lf",&v2);
	printf("Ingrese valor tipo long double\n");
	scanf("%Lf",&v3);

	printf("%f\t%e\t%g\n", v1, v1, v1);
	printf("%lf\t%le\t%lg\n", v2, v2, v2);
	printf("%Lf\t%Le\t%Lg\n", v3, v3, v3);
	return 0;
}

